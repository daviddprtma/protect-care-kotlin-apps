package com.ubaya.protectcare32

data class Location(val id:Int, val name:String, val code:Int){
    override fun toString(): String {
        return name
    }
}
