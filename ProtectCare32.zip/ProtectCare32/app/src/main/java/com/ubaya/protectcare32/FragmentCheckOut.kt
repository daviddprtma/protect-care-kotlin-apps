package com.ubaya.protectcare32

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.fragment_check_out.view.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_USER = "user_checkout"
private const val ARG_LOGGED = "loggedloc"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentCheckOut.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentCheckOut : Fragment() {
    // TODO: Rename and change types of parameters
    private var user: User? = null
    private var logged: History? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            user = it.getParcelable(ARG_USER)
            logged = it.getParcelable(ARG_LOGGED)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_check_out, container, false).apply {
            val vacc_num = logged?.vacc_status
            txtCheckInLocation.text = logged?.location_name
            val dateformatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            val checkin = dateformatter.parse(logged?.checkin_date)
            val dateformatter2 = SimpleDateFormat("EEEE, yyyy-MM-dd, HH:mm")
            val checkin_date = dateformatter2.format(checkin)
            txtCheckInTime.text = checkin_date
            if(vacc_num == 1){
                cardCheckOut.setCardBackgroundColor(resources.getColor(R.color.secondaryvariant))
            }else if(vacc_num == 2){
                cardCheckOut.setCardBackgroundColor(resources.getColor(R.color.primaryvariant))
            }
            btnCheckOut.setOnClickListener {
                val q = Volley.newRequestQueue(activity)
                var url = "https://ubaya.fun/native/160419137/checkout.php"
                val stringRequest = object : StringRequest(Request.Method.POST,url,
                Response.Listener {
                    Log.d("apiresult",it)
                    val obj = JSONObject(it)
                    if(obj.getString("result")=="success"){

                        Toast.makeText(activity,"Check out succesful", Toast.LENGTH_SHORT).show()

                        val checkInFragment = FragmentCheckIn.newInstance(user)
                        activity?.supportFragmentManager?.beginTransaction()?.let {
                            it.replace(R.id.containerCheckMenu, checkInFragment)
                            it.commit()
                        }
                    }else if(obj.getString("result")=="failed"){
                        var builder = AlertDialog.Builder(activity)
                        builder.setTitle("Check Out Failed")

                        builder.setMessage("Could not check out user, Error message : " + obj.getString("message"))
                        builder.setPositiveButton("OK",null)
                        builder.create().show()
                    }
                },Response.ErrorListener {
                    Log.e("apiresult", it.message.toString())

                        var builder = AlertDialog.Builder(activity)
                        builder.setTitle("An Error Occured")

                        builder.setMessage("Error message : " + it.message.toString())
                        builder.setPositiveButton("OK",null)
                        builder.create().show()
                    }){
                    override fun getParams(): MutableMap<String, String> {
                        val params = HashMap<String,String>()

                        val curtime = Calendar.getInstance().time
                        val dateformat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                        val checkout_date = dateformat.format(curtime)

                        params["id"] = user?.id.toString()
                        params["checkin_date"] = logged?.checkin_date.toString()
                        params["checkout_date"] = checkout_date
                        params["location"] = logged?.location_name.toString()

                        return params
                    }
                }
                q.add(stringRequest)
            }
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentCheckOut.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(user:User?, logged:History) =
            FragmentCheckOut().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_USER,user)
                    putParcelable(ARG_LOGGED,logged)
                }
            }
    }
}