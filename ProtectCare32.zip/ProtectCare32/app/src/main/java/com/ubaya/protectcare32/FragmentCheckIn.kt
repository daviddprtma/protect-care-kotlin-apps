package com.ubaya.protectcare32

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.fragment_check_in.*
import kotlinx.android.synthetic.main.fragment_check_in.view.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_USER = "user_checkin"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentCheckIn.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentCheckIn : Fragment() {
    // TODO: Rename and change types of parameters
    private var user: User? = null
    var locations:ArrayList<Location> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            user = it.getParcelable(ARG_USER)
        }

        val q = Volley.newRequestQueue(activity)
        var url = "https://ubaya.fun/native/160419137/get_location.php"
        var stringRequest = StringRequest(Request.Method.POST, url,
        Response.Listener {
            Log.d("apiresult",it)
            val obj = JSONObject(it)
            if(obj.getString("result")=="success"){
                val data = obj.getJSONArray("data")

                for(i in 0 until data.length()){
                    val locObj = data.getJSONObject(i)
                    val location = Location(locObj.getInt("id"),
                    locObj.getString("name"),
                    locObj.getInt("code"))

                    locations.add(location)
                }

                updateSpinner()
            }
        },Response.ErrorListener {
                Log.e("apiresult", it.message.toString())
            })
        q.add(stringRequest)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_check_in, container, false).apply {
            btnCheckIn.setOnClickListener {
                val selectedLoc:Location = locations[spinnerLocation.selectedItemId.toInt()]
                val code = (txtLocCode.text.toString()).toInt()
                if(selectedLoc.code == code){
                    val q = Volley.newRequestQueue(activity)
                    var url = "https://ubaya.fun/native/160419137/checkin.php"
                    val stringRequest = object : StringRequest(Request.Method.POST,url,
                        Response.Listener {
                            Log.d("apiresult",it)
                            val obj = JSONObject(it)
                            if(obj.getString("result")=="success"){
                                val hisQ = Volley.newRequestQueue(activity)
                                val hisUrl = "https://ubaya.fun/native/160419137/get_checkedin.php"
                                val hisRequest = object : StringRequest(Request.Method.POST,hisUrl,
                                    Response.Listener {
                                        Log.d("apiresult",it)
                                        val hisObj = JSONObject(it)
                                        if(hisObj.getString("result")=="success"){
                                            val data = hisObj.getJSONArray("data")
                                            val loggedObj = data.getJSONObject(0)

                                            val loggedLoc:History = History(loggedObj.getString("name"),
                                                loggedObj.getString("checkin_date"),"",
                                                loggedObj.getInt("user_vacc_status"))

                                            Toast.makeText(activity,"Check in succesful", Toast.LENGTH_SHORT).show()

                                            val checkOutFragment = FragmentCheckOut.newInstance(user,loggedLoc)
                                            activity?.supportFragmentManager?.beginTransaction()?.let {
                                                it.replace(R.id.containerCheckMenu, checkOutFragment)
                                                it.commit()
                                            }
                                        }
                                    },Response.ErrorListener {
                                        Log.e("apiresult", it.message.toString())
                                    }){
                                    override fun getParams(): MutableMap<String, String> {
                                        val params = HashMap<String,String>()

                                        params["id"] = user?.id.toString()

                                        return params
                                    }
                                }
                                hisQ.add(hisRequest)
                            }else if(obj.getString("result")=="failed"){
                                var builder = AlertDialog.Builder(activity)
                                builder.setTitle("Check In Failed")

                                builder.setMessage("Could not check in user, Error message : " + obj.getString("message"))
                                builder.setPositiveButton("OK",null)
                                builder.create().show()
                            }
                        },Response.ErrorListener {
                            Log.e("apiresult", it.message.toString())

                            var builder = AlertDialog.Builder(activity)
                            builder.setTitle("An Error Occured")

                            builder.setMessage("Error message : " + it.message.toString())
                            builder.setPositiveButton("OK",null)
                            builder.create().show()
                        }){
                        override fun getParams(): MutableMap<String, String> {
                            val params = HashMap<String,String>()

                            val curtime = Calendar.getInstance().time
                            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                            val checkin_date = dateFormat.format(curtime)

                            params["user_id"] = user?.id.toString()
                            params["location_id"] = selectedLoc.id.toString()
                            params["checkin_date"] = checkin_date
                            params["vacc_status"] = user?.VaccStatus.toString()

                            return params
                        }
                    }

                    q.add(stringRequest)
                }else{
                    var builder = AlertDialog.Builder(activity)
                    builder.setTitle("Unable to check in")

                    builder.setMessage("Location code incorrect")
                    builder.setPositiveButton("OK",null)
                    builder.create().show()
                }
            }


        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentCheckIn.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(user:User?) =
            FragmentCheckIn().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_USER,user)
                }
            }
    }

    fun updateSpinner(){
        requireActivity().run {
            val adapter = ArrayAdapter(this, R.layout.spinner_layout, locations)
            adapter.setDropDownViewResource(R.layout.spinner_item_layout)
            spinnerLocation.adapter = adapter
        }
    }
}