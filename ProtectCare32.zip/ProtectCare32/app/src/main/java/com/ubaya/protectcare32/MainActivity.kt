package com.ubaya.protectcare32

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TimeUtils
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.sql.Time

class MainActivity : AppCompatActivity() {
    val fragments: ArrayList<Fragment> = ArrayList()
    var user:User = User(0,"","",0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sharedFile = "com.ubaya.protectcare32"
        val shared:SharedPreferences = getSharedPreferences(sharedFile,Context.MODE_PRIVATE)
        val userid = shared.getInt("LOGGED_USERID",0)

        val q = Volley.newRequestQueue(this)
        val url = "https://ubaya.fun/native/160419137/login.php"
        val stringRequest = object : StringRequest(
            Request.Method.POST,url,
            Response.Listener {
                Log.d("apiresult",it)
                val obj = JSONObject(it)
                if(obj.getString("result")=="success"){
                    val arr = obj.getJSONArray("data")
                    val data = arr.getJSONObject(0)

                    user.id = data.getInt("id")
                    user.username = data.getString("username")
                    user.name = data.getString("name")
                    user.VaccStatus = data.getInt("vacc_status")
                }

                finishSetup()
            },Response.ErrorListener {
                Log.e("apiresult", it.message.toString())
            }){
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()

                params["id"] = userid.toString()

                return params
            }
        }
        q.add(stringRequest)
    }

    fun finishSetup(){
        fragments.add(FragmentCheckMenu.newInstance(user))
        fragments.add(FragmentHistory.newInstance(user))
        fragments.add(FragmentProfile.newInstance(user))

        viewPager.adapter = ViewPagerAdapter(this, fragments)
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                btnNavMenu.selectedItemId = btnNavMenu.menu.getItem(position).itemId
                super.onPageSelected(position)
            }
        })

        btnNavMenu.setOnNavigationItemSelectedListener {
            viewPager.currentItem = when(it.itemId){
                R.id.itemCheckIn -> 0
                R.id.itemHistory -> 1
                R.id.itemProfile -> 2
                else -> 0
            }
            true
        }
    }
}