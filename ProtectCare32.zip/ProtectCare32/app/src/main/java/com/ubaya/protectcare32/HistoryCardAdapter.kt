package com.ubaya.protectcare32

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.card_history.view.*
import java.text.SimpleDateFormat

class HistoryCardAdapter(val histories:ArrayList<History>):RecyclerView.Adapter<HistoryCardAdapter.HistoryViewHolder>() {
    class HistoryViewHolder(val v:View):RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        var v = inflater.inflate(R.layout.card_history,parent,false)
        return HistoryViewHolder(v)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val history = histories[position]
        with(holder.v){
            txtHistoryLocation.text = history.location_name
            val dateformat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            val dateformat2 = SimpleDateFormat("EEEE, yyyy-MM-dd, HH:mm")
            var checkout_date = ""
            if(history.checkout_date!="User havent checked out yet"){
                val checkout = dateformat.parse(history.checkout_date)
                checkout_date = dateformat2.format(checkout)
            }else{
                checkout_date = history.checkout_date
            }
            val checkin = dateformat.parse(history.checkin_date)
            val checkin_date = dateformat2.format(checkin)

            txtHistoryCheckInTime.text = checkin_date
            txtHistoryCheckOutTime.text = checkout_date
            if(history.vacc_status == 1){
                historyCard.setCardBackgroundColor(resources.getColor(R.color.secondaryvariant))
            }else if(history.vacc_status == 2){
                historyCard.setCardBackgroundColor(resources.getColor(R.color.primaryvariant))
            }
        }
    }

    override fun getItemCount(): Int {
        return histories.size
    }
}