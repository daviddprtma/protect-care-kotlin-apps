package com.ubaya.protectcare32

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class History(val location_name:String, val checkin_date:String,  var checkout_date:String, val vacc_status:Int) : Parcelable
