package com.ubaya.protectcare32

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.fragment_history.view.*
import org.json.JSONObject
import java.sql.Time

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_USER = "user_history"
/**
 * A simple [Fragment] subclass.
 * Use the [FragmentHistory.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentHistory : Fragment() {
    // TODO: Rename and change types of parameters
    private var user: User? = null
    var histories:ArrayList<History> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            user = it.getParcelable(ARG_USER)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_history, container, false).apply {
            val q = Volley.newRequestQueue(activity)
            var url = "https://ubaya.fun/native/160419137/get_history.php"
            var stringRequest = object :  StringRequest(Request.Method.POST,url,
                Response.Listener {
                    Log.d("apiresult",it)
                    val obj = JSONObject(it)
                    if(obj.getString("result")=="success"){
                        val data = obj.getJSONArray("data")

                        for (i in 0 until data.length()){
                            val historyObj = data.getJSONObject(i)
                            var checkout = ""
                            if (historyObj.getString("checkout_date") == "null"){
                                checkout = "User havent checked out yet"
                            }else{
                                checkout = historyObj.getString("checkout_date")
                            }
                            val history = History(historyObj.getString("name"),
                                historyObj.getString("checkin_date"),
                                checkout,
                                historyObj.getInt("user_vacc_status"))

                            histories.add(history)
                        }

                        updateCard()

                        fabRefresh.setOnClickListener {
                            forceUpdateHistory()
                        }
                    }
                },Response.ErrorListener {
                    Log.e("apiresult", it.message.toString())
                }){
                override fun getParams(): MutableMap<String, String> {
                    val params = HashMap<String,String>()

                    params["id"] = user?.id.toString()

                    return params
                }
            }
            q.add(stringRequest)
        }

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentHistory.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(user: User) =
            FragmentHistory().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_USER, user)
                }
            }
    }

    fun updateCard(){
        val lm:LinearLayoutManager = LinearLayoutManager(activity)
        val recyclerView = view?.findViewById<RecyclerView>(R.id.recyclerHistory)
        recyclerView?.layoutManager = lm
        recyclerView?.setHasFixedSize(true)
        recyclerView?.adapter = HistoryCardAdapter(histories)
    }

    fun forceUpdateHistory(){
        val q = Volley.newRequestQueue(activity)
        var url = "https://ubaya.fun/native/160419137/get_history.php"
        var stringRequest = object :  StringRequest(Request.Method.POST,url,
            Response.Listener {
                Log.d("apiresult",it)
                val obj = JSONObject(it)
                if(obj.getString("result")=="success"){
                    histories.clear()
                    val data = obj.getJSONArray("data")

                    for (i in 0 until data.length()){
                        val historyObj = data.getJSONObject(i)
                        var checkout = ""
                        if (historyObj.getString("checkout_date") == "null"){
                            checkout = "User havent checked out yet"
                        }else{
                            checkout = historyObj.getString("checkout_date")
                        }
                        val history = History(historyObj.getString("name"),
                            historyObj.getString("checkin_date"),
                            checkout,
                            historyObj.getInt("user_vacc_status"))

                        histories.add(history)
                    }

                    updateCard()
                }
            },Response.ErrorListener {
                Log.e("apiresult", it.message.toString())
            }){
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String,String>()

                params["id"] = user?.id.toString()

                return params
            }
        }
        q.add(stringRequest)
    }
}