package com.ubaya.protectcare32

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_profile.view.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_USER = "user_profile"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentProfile.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentProfile : Fragment() {
    // TODO: Rename and change types of parameters
    private var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            user = it.getParcelable(ARG_USER)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false).apply {
            val vacc_num = user?.VaccStatus

            txtProfileName.text = user?.name
            txtProfileVacNum.text = vacc_num.toString()
            if(vacc_num == 1){
                cardProfile.setCardBackgroundColor(resources.getColor(R.color.secondaryvariant))
            }else if(vacc_num == 2){
                cardProfile.setCardBackgroundColor(resources.getColor(R.color.primaryvariant))
            }

            fabLogOut.setOnClickListener {
                requireActivity().run {
                    var sharedFile = "com.ubaya.protectcare32"
                    var shared:SharedPreferences = getSharedPreferences(sharedFile,Context.MODE_PRIVATE)

                    var editor:SharedPreferences.Editor = shared.edit()
                    editor.putInt("LOGGED_USERID",0)
                    editor.apply()

                    Toast.makeText(activity,"Log out succesful", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                    this.finish()
                }
            }
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentProfile.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(user:User) =
            FragmentProfile().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_USER,user)
                }
            }
    }
}