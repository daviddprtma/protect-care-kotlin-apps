package com.ubaya.protectcare32

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val sharedFile = "com.ubaya.protectcare32"
        val shared:SharedPreferences = getSharedPreferences(sharedFile,Context.MODE_PRIVATE)

        val mainIntent = Intent(this, MainActivity::class.java)

        if(shared.getInt("LOGGED_USERID",0)>0){
            startActivity(mainIntent)
            this.finish()
        }else{
            btnLogin.setOnClickListener {

                val username = txtUsername.text.toString()
                val pass = txtPassword.text.toString()

                var builder = AlertDialog.Builder(this)

                if(username != "" && pass != ""){
                    val q = Volley.newRequestQueue(this)
                    val url = "https://ubaya.fun/native/160419137/login.php"
                    var stringRequest = object : StringRequest(
                        Request.Method.POST,url,
                        Response.Listener<String> {
                            Log.d("apiresult",it)
                            val obj = JSONObject(it)
                            if(obj.getString("result") == "success"){
                                val id = obj.getInt("data")

                                var editor:SharedPreferences.Editor = shared.edit()
                                editor.putInt("LOGGED_USERID",id)
                                editor.apply()

                                Toast.makeText(this,"Login successful", Toast.LENGTH_SHORT).show()

                                startActivity(mainIntent)
                                this.finish()
                            }else{
                                builder.setTitle("An Error Occured")
                                builder.setMessage("Error message : " + obj.getString("message"))
                                builder.setPositiveButton("OK",null)
                                builder.create().show()
                            }
                        },Response.ErrorListener {
                            Log.e("apiresult", it.message.toString())

                            builder.setTitle("An Error Occured")
                            builder.setMessage("Error message : " + it.message.toString())
                            builder.setPositiveButton("OK",null)
                            builder.create().show()
                        }){
                        override fun getParams(): MutableMap<String, String> {
                            val params = HashMap<String, String>()
                            params["username"] = username
                            params["password"] = pass

                            return params
                        }
                    }
                    q.add(stringRequest)
                }else{
                    builder.setTitle("Error")
                    builder.setMessage("Please input username and password")
                    builder.setPositiveButton("OK",null)
                    builder.create().show()
                }
            }
        }
    }
}