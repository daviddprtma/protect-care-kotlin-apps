package com.ubaya.protectcare32

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_USER = "user_checkmenu"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentCheckMenu.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentCheckMenu : Fragment() {
    // TODO: Rename and change types of parameters
    private var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            user = it.getParcelable(ARG_USER)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_check_menu, container, false).apply {
            val q = Volley.newRequestQueue(activity)
            var url = "https://ubaya.fun/native/160419137/get_checkedin.php"
            val stringRequest = object : StringRequest(Request.Method.POST, url,
                Response.Listener {
                    Log.d("apiresult",it)
                    val obj = JSONObject(it)
                    if(obj.getString("result")=="success"){
                        val data = obj.getJSONArray("data")
                        val loggedObj = data.getJSONObject(0)

                        val loggedLoc:History = History(loggedObj.getString("name"),
                            loggedObj.getString("checkin_date"),"",
                            loggedObj.getInt("user_vacc_status"))

                        val checkOutFragment = FragmentCheckOut.newInstance(user,loggedLoc)
                        activity?.supportFragmentManager?.beginTransaction()?.let {
                            it.replace(R.id.containerCheckMenu, checkOutFragment)
                            it.commit()
                        }
                    }else if(obj.getString("result")=="failed"){
                        val checkInFragment = FragmentCheckIn.newInstance(user)
                        activity?.supportFragmentManager?.beginTransaction()?.let {
                            it.replace(R.id.containerCheckMenu, checkInFragment)
                            it.commit()
                        }
                    }
                },Response.ErrorListener {
                    Log.e("apiresult", it.message.toString())
                }){
                override fun getParams(): MutableMap<String, String> {
                    val params = HashMap<String,String>()

                    params["id"] = user?.id.toString()

                    return params
                }
            }
            q.add(stringRequest)
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentCheckMenu.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(userparam:User) =
            FragmentCheckMenu().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_USER, userparam)
                }
            }
    }
}