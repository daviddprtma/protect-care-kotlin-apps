<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "native_160419137","ubaya","native_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);
    $id = (int)$id;
    $sql = "SELECT location.name, history.checkin_date, history.checkout_date, history.user_vacc_status FROM history INNER JOIN location ON history.location_id=location.id WHERE history.user_id=? ORDER BY history.checkin_date DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i",$id);
    if($stmt->execute()){
        $result = $stmt->get_result();
        $data=[];
        if ($result->num_rows > 0) {
            while($r=mysqli_fetch_assoc($result)){
                array_push($data,$r);
            }

            $arr=["result"=>"success","data"=>$data];
        }else{
            $arr=["result"=>"error","message"=>"No user found"];
        }
    }else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }

    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>