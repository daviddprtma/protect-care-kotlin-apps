<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "native_160419137","ubaya","native_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);

    $presql = "SELECT * FROM location WHERE name=?";
    $prestmt = $conn->prepare($presql);
    $prestmt->bind_param("s",$location);
    if($prestmt->execute()){
        $preresult = $prestmt->get_result();
        if ($preresult->num_rows > 0) {
            $prerow = $preresult->fetch_assoc();
            $locid = $prerow["id"];
        }else{
            $arr=["result"=>"error","message"=>"Location not found"];
        }

        $id = (int)$id;
        $sql = "UPDATE history SET checkout_date = ? WHERE user_id=? AND checkin_date=? AND location_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sisi",$checkout_date,$id,$checkin_date,$locid);
        if($stmt->execute()){
            if ($stmt->affected_rows > 0) {
                $arr=["result"=>"success","data"=>"User have been checked out"];
            }else{
                $arr=["result"=>"failed","message"=>"No user found"];
            }
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }

    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>