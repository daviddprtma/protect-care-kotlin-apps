<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "native_160419137","ubaya","native_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }

    $sql = "SELECT * FROM location";
    $result = $conn->query($sql);
    $data=[];
    if ($result->num_rows > 0) {
        while($r=mysqli_fetch_assoc($result)){
            array_push($data,$r);
        }
        $arr=["result"=>"success","data"=>$data];
    }else{
        $arr=["result"=>"error","message"=>"No user found"];
    }

    echo json_encode($arr);
    $conn->close();
?>