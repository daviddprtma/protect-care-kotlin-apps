<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "native_160419137","ubaya","native_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);

    $user_id = (int)$user_id;
    $location_id = (int)$location_id;
    $vacc_status = (int)$vacc_status;
    $sql = "INSERT INTO history (user_id,location_id,checkin_date,user_vacc_status) VALUES (?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisi",$user_id,$location_id,$checkin_date,$vacc_status);
    if($stmt->execute()){
        if ($stmt->affected_rows > 0) {
            $arr=["result"=>"success","data"=>"User check in success"];
        }else{
            $arr=["result"=>"failed","message"=>"No user found"];
        }
    }else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }

    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>